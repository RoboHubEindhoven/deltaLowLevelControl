# delta-lowlevelcontrol

The lowlevelControl module contains the logic for:
1. Control 4 Motors 
2. Read 4 encoders 
3. Read e-stop state 
4. Instruction decoder 
for more in depth please refer to the report 

## Getting Started 

### prerequisites 
* Vivado 2017.4
* Petalinux 2017.4
* Ubuntu 18.4
* Zybo Z7 

